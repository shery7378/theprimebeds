export function saveHistory(input, reply) {
  chrome.storage.local.get({ history: [] }, function (result) {
    const history = result.history;
    history.unshift({ input, reply, time: new Date().toLocaleString() });
    chrome.storage.local.set({ history: history.slice(0, 10) });
  });
}

export function loadHistory(container) {
  chrome.storage.local.get({ history: [] }, function (result) {
    const history = result.history;
    container.innerHTML = '';
    history.forEach(item => {
      const div = document.createElement('div');
      div.innerHTML = `<strong>${item.time}</strong><br><em>${item.input}</em><br>${item.reply}<hr>`;
      container.appendChild(div);
    });
  });
}