import { generateReply } from './gpt.js';
import { saveHistory, loadHistory } from './storage.js';

document.addEventListener("DOMContentLoaded", () => {
  const input = document.getElementById("inputText");
  const output = document.getElementById("output");
  const generateBtn = document.getElementById("generateBtn");
  const historyDiv = document.getElementById("history");

  generateBtn.onclick = async () => {
    const inputText = input.value.trim();
    if (!inputText) return;

    output.textContent = "Generating...";
    const reply = await generateReply(inputText);
    output.textContent = reply;

    saveHistory(inputText, reply);
    loadHistory(historyDiv);
  };

  loadHistory(historyDiv);
});