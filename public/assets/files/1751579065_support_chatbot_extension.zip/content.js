document.addEventListener('mouseup', () => {
  const selection = window.getSelection().toString();
  if (selection.length > 0) {
    chrome.storage.local.set({ selectedText: selection });
  }
});