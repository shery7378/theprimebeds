export async function generateReply(inputText) {
  const apiKey = localStorage.getItem('openai_api_key');
  if (!apiKey) return "Please set your OpenAI API key in localStorage.";

  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "gpt-4",
      messages: [
        { role: "system", content: "You are a helpful, professional, and empathetic customer support agent." },
        { role: "user", content: inputText }
      ],
      temperature: 0.7
    })
  });

  const data = await response.json();
  return data.choices[0].message.content.trim();
}